package com.example.myapplication

import android.os.Bundle
import android.view.View
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat

class MainActivity : AppCompatActivity(), View.OnClickListener {

    lateinit var btnC : Button
    lateinit var btnF : Button
    lateinit var btnK : Button

    lateinit var et_a : EditText

    lateinit var res_C : TextView
    lateinit var res_F : TextView
    lateinit var res_K : TextView


    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        btnC = findViewById(R.id.btn_C)
        btnF = findViewById(R.id.btn_F)
        btnK = findViewById(R.id.btn_K)

        et_a = findViewById(R.id.et_a)

        res_C = findViewById(R.id.rest_C)
        res_F = findViewById(R.id.rest_F)
        res_K = findViewById(R.id.rest_K)

        btnC.setOnClickListener(this)
        btnF.setOnClickListener(this)
        btnK.setOnClickListener(this)



    }

    override fun onClick(v: View?) {
        var a=et_a.text.toString().toDouble()
        var resultC=0.0
        var resultF=0.0
        var resultK=0.0

        when(v?.id){
            R.id.btn_C ->{
                resultC = a
                resultF = ((9*a)/5)+32
                resultK = a+273.5
            }
            R.id.btn_F ->{
                resultF = a
                resultC = (5*(a-32))/9
                resultK = ((5*(a-32))/9)+5

            }
            R.id.btn_K ->{
                resultK = a
                resultC = a-273.5
                resultF = ((9*(a-273.5))/5)+32
            }
        }
        res_C.text = "Grados Celsius: $resultC"
        res_F.text = "Grados Celsius: $resultF"
        res_K.text = "Grados Celsius: $resultK"

    }

}